import React, { Component } from 'react';

class Li extends Component {
    render(){
        return (
            <li>{this.props.txt1}</li>
        )
    }
}

export default Li;