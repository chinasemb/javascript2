let app = {
	data:["1"]
}

export default app;