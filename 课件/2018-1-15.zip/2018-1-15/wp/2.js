import {fn} from './1';
console.log(fn() + 2); //3