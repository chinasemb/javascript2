function fn(){
    return 1;
}
export {fn};