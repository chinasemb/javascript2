// module.exports = {
//     num:10
// }

module.exports = fn;

// module.exports.fn = fn;

function fn(){
    return 1;
}
