<?php
$ymjz = file_get_contents('http://www.kaola.com/getSuggestKeyword.html?query=猫&size=10');
//http://www.kaola.com/getSuggestKeyword.html?query=猫&size=10
echo $ymjz;
//http://192.168.2.63/2017-8-3/json_get.php