const mongoose = require('mongoose');
module.exports = mongoose.model('users',require('../schema/users'));


