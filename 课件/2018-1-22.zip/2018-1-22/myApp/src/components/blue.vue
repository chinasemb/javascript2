<template>
  <div class="div3">

  </div>
</template>
<script>
export default {
  name:'blue'
}
</script>
<style>
  .div3{
    width:100px;
    height: 100px;
    background:blue;
  }
</style>
