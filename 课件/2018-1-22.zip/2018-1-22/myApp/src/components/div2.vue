<template>
  <div class="div2">

  </div>
</template>
<script>
export default {
  name:'yellow'
}
</script>
<style>
  .div2{
    width:100px;
    height: 100px;
    background:yellow
  }
</style>
