// console.log(123);
module.exports = {
    text:1
}