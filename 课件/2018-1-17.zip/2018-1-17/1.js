export default function fn(){
    return 10;
}