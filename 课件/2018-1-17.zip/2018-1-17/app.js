import fn from './1';
require('./1.css');
console.log(fn());
